# ASIC BCJRFormer RTL simulation and audit logs

This archive contains all seven log files retained on disk from the trained-frame simulation and its audit. The numbered logs are verbatim copies under descriptive names. SHA256SUMS.txt records their hashes.

## Where to start

Open **03-trained-frame-rtl-run.log**. The end of the log records completion code 0, cycle 1,533,280,239, and 144/144 exact integer output matches with the fixed-point Python reference. This is evidence for one unpadded, single-read trained frame. The run took about 8 hours 7 minutes on the Windows PC.

## Log index

| File | Contents |
| --- | --- |
| 01-trained-frame-yosys-build.log | Full-size elaboration and CXXRTL generation. Slang reports zero elaboration errors and warnings. Yosys separately warns that feedback wires require delta cycles. |
| 02-trained-frame-compiler-log-empty.log | Original zero-byte compiler log from an earlier compilation. It does not document the final executable build. |
| 03-trained-frame-rtl-run.log | Parameter-load milestones, frame acceptance, progress, completion status, and final match count. |
| 04-audit-trained-frame-yosys-rebuild.log | Fresh build of the same trained dimensions during the audit. Applying the same local division/remainder cache to the rebuilt C++ reproduced the saved generated model byte for byte. |
| 05-audit-small-fixture-yosys-build.log | Build of the small two-output fixture used to test the driver. |
| 06-audit-small-fixture-uncached-compiler-log-empty.log | Zero-byte compiler output from the unmodified CXXRTL fixture build. |
| 07-audit-small-fixture-cached-compiler-log-empty.log | Zero-byte compiler output from the cached CXXRTL fixture build. |

## Audit checks reported in the terminal

These observations summarize terminal output from the audit. They are not additional raw log files.

- A fresh conversion and fixed-point Python run reproduced the tensor JSON, parameter image, input frame, and expected logits byte for byte.
- The original full-size comparison CSV had 144 output rows, and every observed RTL word matched the regenerated reference at the same position.
- The small fixture gave 2/2 exact matches at cycle 18,823 with and without the local cache. Deliberately changing one expected word gave 1/2 exact matches and a failing exit code.
- The full trained-frame run used the cache. An independent run in the lab simulator remains open.

The archive contains logs and this index. Weights, input features, per-position CSV results, credentials, and simulator binaries are excluded.
